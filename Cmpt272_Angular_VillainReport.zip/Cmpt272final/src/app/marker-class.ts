export class markerClass{
    constructor(
        public marker:L.Marker,
        public name:string
    ){}
}