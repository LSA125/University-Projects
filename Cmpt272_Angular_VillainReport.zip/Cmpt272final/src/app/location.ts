export class Location {
    public count:number = 0
    constructor(
    public name:string,
    public longitude:number,
    public latitude:number,
    ){}
}
